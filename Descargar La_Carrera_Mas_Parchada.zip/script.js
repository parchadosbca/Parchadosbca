
document.getElementById("registroForm").addEventListener("submit", function(e) {
  e.preventDefault();

  const nombre = e.target.nombre.value;
  const cedula = e.target.cedula.value;
  const telefono = e.target.telefono.value;
  const edad = e.target.edad.value;
  const barrio = e.target.barrio.value;

  const numeroInscripcion = "RUN" + Math.floor(100000 + Math.random() * 900000);

  const resultado = `
    ¡Gracias por inscribirte, ${nombre}!<br>
    Tu número de inscripción es: <strong>${numeroInscripcion}</strong>
  `;

  document.getElementById("resultado").innerHTML = resultado;

  e.target.reset(); // Limpia el formulario
});
